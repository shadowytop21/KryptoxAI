"use client"

import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Bot, MessageSquare, Phone, MessageCircle, ArrowRight, Sparkles, Zap, Shield } from "lucide-react"

export default function Home() {
  return (
    <div className="min-h-screen bg-background">
      {/* Hero Section */}
      <header className="container mx-auto px-4 py-16 md:py-24">
        <div className="text-center space-y-6">
          <h1 className="text-4xl md:text-6xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-blue-500 to-purple-500">
            Enterprise-Grade Kryptox AI Solutions
          </h1>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Premium AI automation solutions with no free tiers - Quality Comes at a Price
          </p>
          <div className="flex gap-4 justify-center">
            <Button size="lg" className="bg-gradient-to-r from-blue-500 to-purple-500 hover:from-blue-600 hover:to-purple-600">
              Get Started <ArrowRight className="ml-2 h-4 w-4" />
            </Button>
            <Button size="lg" variant="outline">
              Book a Demo
            </Button>
          </div>
        </div>
      </header>

      {/* Services Section */}
      <section className="container mx-auto px-4 py-16">
        <h2 className="text-3xl font-bold text-center mb-12">Our AI Solutions</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <Card className="bg-card/50 backdrop-blur border-muted">
            <CardContent className="p-6 space-y-4">
              <Bot className="h-12 w-12 text-blue-500" />
              <h3 className="text-xl font-semibold">AI Chatbots</h3>
              <p className="text-muted-foreground">
                Intelligent conversational agents that handle customer inquiries 24/7 with human-like understanding.
              </p>
            </CardContent>
          </Card>

          <Card className="bg-card/50 backdrop-blur border-muted">
            <CardContent className="p-6 space-y-4">
              <Phone className="h-12 w-12 text-purple-500" />
              <h3 className="text-xl font-semibold">Voice Assistants</h3>
              <p className="text-muted-foreground">
                Natural voice interactions powered by advanced speech recognition and synthesis.
              </p>
            </CardContent>
          </Card>

          <Card className="bg-card/50 backdrop-blur border-muted">
            <CardContent className="p-6 space-y-4">
              <MessageCircle className="h-12 w-12 text-green-500" />
              <h3 className="text-xl font-semibold">WhatsApp Automation</h3>
              <p className="text-muted-foreground">
                Seamless integration with WhatsApp for automated customer engagement and support.
              </p>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* Features Section */}
      <section className="container mx-auto px-4 py-16 bg-accent/5 rounded-3xl my-16">
        <h2 className="text-3xl font-bold text-center mb-12">Why Choose Us</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div className="flex flex-col items-center text-center space-y-4">
            <div className="h-12 w-12 rounded-full bg-blue-500/10 flex items-center justify-center">
              <Sparkles className="h-6 w-6 text-blue-500" />
            </div>
            <h3 className="text-xl font-semibold">Advanced AI Technology</h3>
            <p className="text-muted-foreground">
              Cutting-edge machine learning models for superior understanding and responses.
            </p>
          </div>

          <div className="flex flex-col items-center text-center space-y-4">
            <div className="h-12 w-12 rounded-full bg-purple-500/10 flex items-center justify-center">
              <Zap className="h-6 w-6 text-purple-500" />
            </div>
            <h3 className="text-xl font-semibold">Quick Integration</h3>
            <p className="text-muted-foreground">
              Seamless setup process with your existing systems and workflows.
            </p>
          </div>

          <div className="flex flex-col items-center text-center space-y-4">
            <div className="h-12 w-12 rounded-full bg-green-500/10 flex items-center justify-center">
              <Shield className="h-6 w-6 text-green-500" />
            </div>
            <h3 className="text-xl font-semibold">Enterprise Security</h3>
            <p className="text-muted-foreground">
              Bank-grade security measures to protect your data and conversations.
            </p>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="container mx-auto px-4 py-16">
        <div className="bg-gradient-to-r from-blue-500/10 to-purple-500/10 rounded-3xl p-8 md:p-16 text-center space-y-6">
          <h2 className="text-3xl md:text-4xl font-bold">Ready to Transform Your Business?</h2>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Join the AI revolution and stay ahead of the competition with our intelligent solutions.
          </p>
          <Button size="lg" className="bg-gradient-to-r from-blue-500 to-purple-500 hover:from-blue-600 hover:to-purple-600">
            Contact Us Today
          </Button>
        </div>
      </section>
    </div>
  )
}