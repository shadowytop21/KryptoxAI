import './globals.css';
import type { Metadata } from 'next';
import { Inter } from 'next/font/google';
import { ThemeProvider } from "@/components/theme-provider";

const inter = Inter({
  subsets: ['latin'],
  display: 'swap',
  variable: '--font-inter',
});

export const metadata: Metadata = {
  title: 'AIForge - Advanced AI Solutions',
  description: 'Transforming businesses with cutting-edge AI solutions - chatbots, voice assistants, and WhatsApp automation.',
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en" suppressHydrationWarning className={inter.variable}>
      <body className="antialiased bg-background">
        <ThemeProvider 
          attribute="class"
          defaultTheme="dark"
          enableSystem={false}
          forcedTheme="dark"
          disableTransitionOnChange
          storageKey="aiforge-theme"
        >
          {children}
        </ThemeProvider>
      </body>
    </html>
  );
}